import { useEffect, useState } from 'react'
import './index.css'
import Header from './components/Header'
import AddTodoForm from './components/AddTodoForm'
import TodoList from './components/TodoList'
import Stats from './components/Stats'
import './App.css'
import './index.css'

function App() {
  const [todos, setTodos] = useState(() => {
    try {
      const saved = localStorage.getItem('todos-v1')
      return saved ? JSON.parse(saved) : []
    } catch {
      return []
    }
  })

  useEffect(() => {
    localStorage.setItem('todos-v1', JSON.stringify(todos))
  }, [todos])

  function handleAdd(text) {
    const newTodo = { id: crypto.randomUUID(), text, completed: false }
    setTodos((prev) => [newTodo, ...prev])
  }

  function handleToggle(id) {
    setTodos((prev) => prev.map((t) => t.id === id ? { ...t, completed: !t.completed } : t))
  }

  function handleDelete(id) {
    setTodos((prev) => prev.filter((t) => t.id !== id))
  }

  function handleEdit(id, text) {
    setTodos((prev) => prev.map((t) => t.id === id ? { ...t, text } : t))
  }

  function handleClearAll() {
    setTodos([])
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-sky-50">
      <div className="mx-auto max-w-2xl px-4 py-10">
        <Header title="Minhas Tarefas" onClearAll={handleClearAll} />
        <div className="mt-4 card">
          <AddTodoForm onAdd={handleAdd} />
          <div className="mt-5">
            <TodoList
              todos={todos}
              onToggle={handleToggle}
              onDelete={handleDelete}
              onEdit={handleEdit}
            />
          </div>
          <Stats todos={todos} />
        </div>
      </div>
    </div>
  )
}

export default App
