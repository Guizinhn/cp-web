import { useState } from 'react'

function Header({ title, onClearAll }) {
  const [isHelpOpen, setIsHelpOpen] = useState(false)

  return (
    <header className="py-4">
      <div className="flex items-end justify-between">
        <div>
          <p className="text-sm font-semibold tracking-wide text-indigo-600">Produtividade</p>
          <h1 className="text-4xl font-extrabold tracking-tight text-slate-900">{title}</h1>
        </div>
        <div className="flex items-center gap-2">
          {onClearAll && (
            <button
              className="btn-danger"
              onClick={() => {
                if (confirm('Tem certeza que deseja excluir todas as tarefas?')) {
                  onClearAll()
                }
              }}
            >
              Limpar tudo
            </button>
          )}
          <button
            className="btn-primary"
            onClick={() => setIsHelpOpen((prev) => !prev)}
          >
            <span>Ajuda</span>
          </button>
        </div>
      </div>
      {isHelpOpen && (
        <p className="mt-3 text-sm leading-6 text-slate-600">
          Adicione tarefas, marque como concluídas, edite e remova.
        </p>
      )}
    </header>
  )
}

export default Header


