import { useState } from 'react'

function TodoItem({ todo, onToggle, onDelete, onEdit }) {
  const [isEditing, setIsEditing] = useState(false)
  const [draft, setDraft] = useState(todo.text)

  function handleSave() {
    const trimmed = draft.trim()
    if (!trimmed) return setIsEditing(false)
    onEdit(todo.id, trimmed)
    setIsEditing(false)
  }

  return (
    <li className="card flex items-center gap-3">
      <input
        type="checkbox"
        className="size-4 rounded-sm border-slate-300 text-indigo-600 focus:ring-indigo-500"
        checked={todo.completed}
        onChange={() => onToggle(todo.id)}
      />

      {isEditing ? (
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          className="input flex-1 px-3 py-1"
        />
      ) : (
        <span className={
          `flex-1 ${todo.completed ? 'line-through text-slate-400' : ''}`
        }>
          {todo.text}
        </span>
      )}

      {isEditing ? (
        <div className="flex gap-2">
          <button onClick={handleSave} className="btn-success">Salvar</button>
          <button onClick={() => { setDraft(todo.text); setIsEditing(false) }} className="btn-ghost">Cancelar</button>
        </div>
      ) : (
        <div className="flex gap-2">
          <button onClick={() => setIsEditing(true)} className="btn-ghost">Editar</button>
          <button onClick={() => onDelete(todo.id)} className="btn-danger">Excluir</button>
        </div>
      )}
    </li>
  )
}

export default TodoItem


