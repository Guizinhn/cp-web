import { useState } from 'react'

function AddTodoForm({ onAdd }) {
  const [text, setText] = useState('')

  function handleSubmit(e) {
    e.preventDefault()
    const trimmed = text.trim()
    if (!trimmed) return
    onAdd(trimmed)
    setText('')
  }

  return (
    <form onSubmit={handleSubmit} className="flex flex-col gap-3 sm:flex-row mb-4 card shadow-xl backdrop-blur supports-[backdrop-filter]:bg-white/70">
      <input
        type="text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Descreva sua tarefa..."
        className="input flex-1"
      />
      <button
        type="submit"
        className="btn-primary text-center mb-4 card shadow-xl backdrop-blur supports-[backdrop-filter]:bg-white/70"
      >
        Adicionar
      </button>
    </form>
  )
}

export default AddTodoForm


