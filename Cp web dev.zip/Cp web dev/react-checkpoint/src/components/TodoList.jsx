import TodoItem from './TodoItem'

function TodoList({ todos, onToggle, onDelete, onEdit }) {
  if (todos.length === 0) {
    return (
      <div className="rounded-xl border border-dashed border-slate-300 bg-slate-50 p-6 text-center text-slate-500">
        <p className="font-medium">Nenhuma tarefa ainda</p>
        <p className="text-sm">Adicione a primeira usando o campo acima.</p>
      </div>
    )
  }

  return (
    <ul className="flex flex-col gap-2">
      {todos.map((t) => (
        <TodoItem key={t.id} todo={t} onToggle={onToggle} onDelete={onDelete} onEdit={onEdit} />
      ))}
    </ul>
  )
}

export default TodoList


