function Stats({ todos }) {
  const total = todos.length
  const done = todos.filter((t) => t.completed).length
  const remaining = total - done

  return (
    <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-3">
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <p className="text-xs uppercase tracking-wide text-slate-500">Total</p>
        <p className="text-2xl font-bold text-slate-900">{total}</p>
      </div>
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <p className="text-xs uppercase tracking-wide text-slate-500">Concluídas</p>
        <p className="text-2xl font-bold text-emerald-700">{done}</p>
      </div>
      <div className="rounded-xl border border-slate-200 bg-white p-4 shadow-sm">
        <p className="text-xs uppercase tracking-wide text-slate-500">Pendentes</p>
        <p className="text-2xl font-bold text-amber-700">{remaining}</p>
      </div>
    </div>
  )
}

export default Stats


