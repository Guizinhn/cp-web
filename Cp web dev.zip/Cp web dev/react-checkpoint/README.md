# Minhas Tarefas – Checkpoint 1 (React + Vite)

## Objetivo da aplicação
Aplicação simples de lista de tarefas com possibilidade de adicionar, editar, concluir e remover itens. Os dados são persistidos em `localStorage`.

## Tecnologias usadas
- React (Vite)
- TailwindCSS

## Como executar localmente
```bash
npm install
npm run dev
```

Abra o endereço indicado no terminal (geralmente `http://localhost:5173`).

## Estrutura de componentes
- `Header`: exibe o título e um pequeno help (usa state interno)
- `AddTodoForm`: formulário controlado para adicionar tarefas (usa props e state)
- `TodoList` e `TodoItem`: lista e item com editar/alternar/excluir (props e state)
- `Stats`: contadores de totais, concluídas e pendentes (props)

## Hooks utilizados
- `useState`: controle de estados de formulário, edição e lista de tarefas
- `useEffect`: persistência em `localStorage`

## Estilização
TailwindCSS aplicado em layout, botões, cards e tipografia.
